import Foundation

public func randomBonus(from from: Int, to: Int) -> Int {
    return 20
}