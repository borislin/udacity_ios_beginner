//: ## Using Playgrounds
//: Playground - noun: a place where people can play
import UIKit

var str = "Hello, playground"

// This is a single line comment

/* This is a
    multi-line comment. 

You can write whatever
comments you want between the opening slash/star and
the closing star/slash.

*/
/*:
This multi-line comment uses Markup!
*/
//: [Next](@next)
