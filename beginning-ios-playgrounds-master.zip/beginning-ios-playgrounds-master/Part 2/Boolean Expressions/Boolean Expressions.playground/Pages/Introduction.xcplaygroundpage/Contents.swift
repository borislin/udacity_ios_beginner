//: Boolean Expressions

import UIKit

// Introduction to Boolean Expressions
var age = 5
var timeForKindergarten = age == 5
var canVote = age >= 18
//: [Next](@next)