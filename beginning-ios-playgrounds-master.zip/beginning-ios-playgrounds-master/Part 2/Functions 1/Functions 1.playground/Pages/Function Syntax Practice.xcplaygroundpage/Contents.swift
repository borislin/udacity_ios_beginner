//: [Previous](@previous)
/*:
## Function Syntax Practice
*/
//: ### Exercise 1
//: Define a function called `myFirstFunction` that takes 0 parameters and prints something.
//: **The solution is available on the next page!**

//: [Next](@next)
