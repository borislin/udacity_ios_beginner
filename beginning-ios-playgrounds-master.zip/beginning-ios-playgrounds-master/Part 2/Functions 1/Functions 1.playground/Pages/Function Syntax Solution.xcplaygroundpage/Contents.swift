//: [Previous](@previous)
/*:
## Function Syntax Solution
*/
//: ### Exercise 1
//: Define a function called `myFirstFunction` that takes 0 parameters and prints something.
func myFirstFunction() {
    print("do something crazy!")
}

// and now we can use the function...
myFirstFunction()

//: [Next](@next)
