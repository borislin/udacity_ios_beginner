//: [Previous](@previous)
/*:
## Functions without Params Practice
*/
//: ### Exercise 1
//: Define a function called `printSmileyFaceEmoji` that takes 0 parameters and prints a smiley face emoji! To use emojis and symbols type Control+Command(⌘)+Space to launch the characters keyboard.
//: **The solution is available on the next page!**

//: ### Exercise 2
//: Define a function called `printDogEmoji` that takes 0 parameters and prints a dog emoji! To use emojis and symbols type Control+Command(⌘)+Space to launch the characters keyboard.
//: **The solution is available on the next page!**

//: [Next](@next)
