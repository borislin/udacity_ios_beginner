//: [Previous](@previous)
/*:
## You've Been Using Functions
*/
// we've seen the "print" function before
print("I'm calling a function!")

// you may have used "print" in the Maze app
print("In Storyboard, this function prints strings in the right pane")
//: [Next](@next)
