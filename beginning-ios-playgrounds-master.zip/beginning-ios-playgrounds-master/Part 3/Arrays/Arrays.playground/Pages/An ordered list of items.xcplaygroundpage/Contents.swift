//: Array - An ordered list of items. Duplicates are A-OK!
var favoriteThings = ["raindrops on roses", "whiskers on kittens", "bright copper kettles", "raindrops on roses"]

var firstItem = favoriteThings[0]
var fourthItem = favoriteThings[3]
//: [Next](@next)
