//: [Previous](@previous)

//: ### Array operations: append, insert, remove, count, retrieve
var musicians = ["Neil Young","Kendrick Lamar","Flo Rida", "Fetty Wap"]
musicians.append("Rae Sremmurd")
musicians.insert("Dej Loaf", atIndex: 2)
musicians.removeAtIndex(3)

musicians
musicians.count



let musician = musicians[2]

//: [Next](@next)
