//: [Previous](@previous)

import Foundation
import UIKit

//: ### Declaring optionals with Question Marks
// Example 1
var z: Int
var string: String
string = "123"
//z = Int(string)
//z * 2

// Example 2
class AnotherViewController: UIViewController {
    //var anotherButton: UIButton
}


//: [Next](@next)
