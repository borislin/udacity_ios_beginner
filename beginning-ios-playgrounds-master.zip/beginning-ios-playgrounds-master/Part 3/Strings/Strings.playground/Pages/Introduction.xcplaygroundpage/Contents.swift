//: [Previous](@previous)
//: # Strings
import UIKit
import Foundation
//: ## Introduction
// You've seen strings passed in to print statements
print("Good evening!")

// You've seen strings defined as constants and as variables
let theBaseballTeamInAtlanta = "Atlanta Braves"
var jamesFavoriteBaseballTeam = "Atlanta Braves"

//: [Next](@next)