/*:
## The For Loop
The for loop is another type of loop expression containing three control sections (initialization, test, and update) and block of code.
*/
for var i = 1; i < 11; i += 1 {
    print(i)
}
//: [Next](@next)
