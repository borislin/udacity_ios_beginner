//: [Previous](@previous)
//: ## Introduction to Dictionaries

// A dictionary is an unordered collection of key-value pairs
var phoneNumbers = ["Jenny": "867-5309", "Mateo": "510-7752", "Mike": "330-8004", "Alicia": "489-4608", "Daniel": "455-2626", "Josie": "769-3339"]

phoneNumbers["Alicia"]
//: [Next](@next)
