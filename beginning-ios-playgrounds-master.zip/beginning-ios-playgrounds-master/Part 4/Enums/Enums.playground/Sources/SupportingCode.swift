//
// This file (and all other Swift source files in the Sources directory of this playground) will be precompiled into a framework which is automatically made available to Enums.playground.
//

public struct Person {
    public var name: String
    public var age: Int
    
        public init (name: String, age: Int) {
            self.name = name
            self.age = age
        }
    
}

