//: # Closures

//: ### Closures include:
//: __global functions, nested functions, and closure expressions__

//: ### What is a closure expression?
//: closure expression - __an unnamed, self contained block of code that can be passed as an argument to a function__

//: [Next](@next)
