//: [Previous](@previous)

//: ## What are closure expressions used for?
//: Closure expressions are used to __specify an action to be executed some time in the future__ or __specify an action to be executed on each item in a collection.__ 

//: [Next](@next)

