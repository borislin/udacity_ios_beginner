//: ## map() and reduce()

//: The higher order functions map() and reduce() take advantage of the fact that functions in Swift have all the capabilities of any other object.

//: [Next](@next)

